
import { AngularFireDatabase, AngularFireDatabaseModule,AngularFireList } from '@angular/fire/database';

import { Injectable } from '@angular/core';
import {AngularFireAuth} from '@angular/fire/auth';
import { HttpClient} from '@angular/common/http';

import { Observable } from 'rxjs';
import { first } from 'rxjs/operators';

import * as firebase from 'firebase';
import { Poststructure } from './tab2/poststructure';

@Injectable({
  providedIn: 'root'
})
export class FirebaseServiceService {

  uid:string;
  userName:string;
  dbPath='/posts';
  //fetchedPost:AngularFireList<Poststructure>=null;
  currentUser:any;
  authState:any=null;
  fetchedPost: AngularFireList<Poststructure>;

  constructor(private fireauth:AngularFireAuth,private http:HttpClient,private firedb:AngularFireDatabase) { 
    this.fetchedPost=firedb.list(this.dbPath);


    this.fireauth.authState.subscribe((auth=>{
      this.authState=auth;
    }))
  }


  loginWithEmail(email: string, password: string)
{
  return this.fireauth.signInWithEmailAndPassword(email, password)
    .then((user) => {
      this.authState = user;
     
    })
    .catch(error => {
      console.log(error)

      throw error
    });
}


registerWithEmail(email:string,password:string,userName:string){
  return this.fireauth.createUserWithEmailAndPassword(email,password).then((user)=>
 {
   this.authState=user;
  this.userName=userName;
  //this.setUserName();
 }).catch(error=>{
   console.log(error);
   throw error;

 })
 }
 
 setUserName(){
   var user = firebase.auth().currentUser;
  user.updateProfile({
    displayName:this.userName
  }).then(function(){
    console.log('Register Successful');

  }).catch(function(error){
    console.log(error);

  })
 }


 //feed Module

dbURI='https://iconnect-42324.firebaseio.com/posts.json';

onPostSubmit(PostData:any){
 return this.http.post(this.dbURI,PostData);
}

getAll(): AngularFireList<Poststructure> {
  return this.fetchedPost;
}

isLoggedIn() {
  return this.fireauth.authState.pipe(first()).toPromise();
}






}

