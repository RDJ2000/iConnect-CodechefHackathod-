import { FirebaseServiceService } from './../firebase-service.service';
import { SignupModel } from './signup-model';

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  userName:string;
  password:string;
  emailId:string;
  message='';
  error:{name:string ,message:string}={name:'',message:''};
  SignupModel=new SignupModel('','','');
  constructor(private firebaseService:FirebaseServiceService , private router:Router) { }

  ngOnInit() {
  }
  type:String='Login';
  segmentChanged(ev: any) {
   
  }

  onLogin(){
   
    this.firebaseService.loginWithEmail(this.emailId,this.password)
    .then(()=>{
       this.message='logged from firebase';
       this.router.navigate(['/tabs/tab2']);
    }).catch(_error=>{
      this.error=_error;

    })
    
  }
  onSignupSubmit(){

    this.firebaseService.registerWithEmail(this.emailId,this.password,this.userName)
    .then(()=>{
       this.message='registred on firebase';
       this.router.navigate(['/tabs/tab2']);
    }).catch(_error=>{
      this.error=_error;

    })
    
  }


}
