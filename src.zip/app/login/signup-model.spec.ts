import { SignupModel } from './signup-model';

describe('SignupModel', () => {
  it('should create an instance', () => {
    expect(new SignupModel()).toBeTruthy();
  });
});
