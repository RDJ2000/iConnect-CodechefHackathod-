export class SignupModel {
    constructor(
        public Name:string,
        public emailID:string,
        public Password:string,
    ){}

}


