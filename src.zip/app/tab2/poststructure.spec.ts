import { Poststructure } from './poststructure';

describe('Poststructure', () => {
  it('should create an instance', () => {
    expect(new Poststructure()).toBeTruthy();
  });
});
