import { Router } from '@angular/router';
import { Poststructure } from './poststructure';
import { Component, OnInit } from '@angular/core';
import { FirebaseServiceService } from '../firebase-service.service';

import {formatDate } from '@angular/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page implements OnInit {


  
  userName:string;
  feedText:string;
  postData=new Poststructure('RDJ','','','',[]);
  currentDate=new Date();
  allFeeds:any;
  userComment:string;
  currentUser:string;
  destination:string;


  constructor(private firebaseService:FirebaseServiceService,private router:Router) {}
  ngOnInit(){
    this.getPostFeeds();
  }
  
postFeed(){
  //Date and Time Init
  this.postData.postDate=formatDate(this.currentDate,'dd-MMMM-yyyy', 'en-US', '+0530');
  this.postData.postTime= formatDate(this.currentDate, ' hh:mm a', 'en-US', '+0530');
  this.postData.userName=this.userName;
  this.postData.feedText=this.feedText;
  this.feedText=null;
  //Service Call
  this.firebaseService.onPostSubmit(this.postData).subscribe(
    data=>console.log('success',data),
    error=>console.log('Error!',error)

  )
}

  async getPostFeeds(){
  let User=await this.firebaseService.isLoggedIn();
  this.currentUser=User.email;
  this.userName=User.displayName;
  this.firebaseService.getAll().snapshotChanges().pipe(
    map(changes=>
      changes.map(c =>(
        {key:c.payload.val()}
      )))
  ).subscribe(data=>{
        this.allFeeds=data;
        console.log(this.allFeeds);

      })

}
}
