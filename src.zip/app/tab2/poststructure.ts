export class Poststructure {
    constructor(
        public userName:string,
        public feedText:string,
        public postDate:string,
        public postTime:string,
        public Comment:string[],
    ){
    }
}
